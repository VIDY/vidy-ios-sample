//
//  UILabel+VDYAdditions.h
//  tapdelay
//
//  Created by Arria Owlia on 5/22/18.
//  Copyright © 2018 Vidy. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "VDYAttributedTextDisplay.h"

@interface UILabel (VDYAdditions) <VDYAttributedTextDisplay>

/**
 After swizzling, this method refers to the original -drawRect: implementation.
 */
- (void)vdy_drawRectSwizzled:(CGRect)rect;

/**
 After swizzling, this method refers to the original -setText: implementation.
 */
- (void)vdy_setTextSwizzled:(NSString *_Nullable)text;

/**
 After swizzling, this method refers to the original -setAttributedText: implementation.
 */
- (void)vdy_setAttributedTextSwizzled:(NSAttributedString *_Nullable)attributedText;

/**
 After swizzling, this method refers to the original -setBounds: implementation.
 */
- (void)vdy_setBoundsSwizzled:(CGRect)bounds;

/**
 After swizzling, this method refers to the original -setFrame: implementation.
 */
- (void)vdy_setFrameSwizzled:(CGRect)frame;

@end
