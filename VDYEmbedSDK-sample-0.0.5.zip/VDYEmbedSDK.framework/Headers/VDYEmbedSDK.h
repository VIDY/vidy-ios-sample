//
//  VDYEmbedSDK.h
//  VDYEmbedSDK
//
//  Created by Arria Owlia on 5/29/18.
//  Copyright © 2018 Vidy. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for VDYEmbedSDK.
FOUNDATION_EXPORT double VDYEmbedSDKVersionNumber;

//! Project version string for VDYEmbedSDK.
FOUNDATION_EXPORT const unsigned char VDYEmbedSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VDYEmbedSDK/PublicHeader.h>

#import <VDYEmbedSDK/VDYAttributedTextDisplay.h>
#import <VDYEmbedSDK/NSString+VDYPhraseOccurrence.h>
#import <VDYEmbedSDK/UILabel+VDYAdditions.h>
#import <VDYEmbedSDK/VDYDisplayDelegate.h>
#import <VDYEmbedSDK/VDYEmbedSDKClass.h>
