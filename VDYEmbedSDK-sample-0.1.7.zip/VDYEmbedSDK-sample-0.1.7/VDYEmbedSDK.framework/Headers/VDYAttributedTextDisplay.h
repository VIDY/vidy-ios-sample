//
//  VDYAttributedTextDisplay.h
//  VDYEmbedSDK
//
//  Created by Arria Owlia on 5/31/18.
//  Copyright © 2018 Vidy. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol VDYDisplayDelegate;

@protocol VDYAttributedTextDisplay <NSObject>

/**
 Delegate to be invoked during any Vidy-initiated text changing operations.
 */
@property (nullable, nonatomic, weak) id<VDYDisplayDelegate> vdy_displayDelegate;

/**
 Specifies whether this label is activated and may be used for Vidy rendering.
 */
@property (nonatomic, readonly) BOOL vdy_activated;

/**
 Specifies the view controller instance that hosts this object.
 */
@property (nullable, nonatomic, weak) UIViewController *vdy_viewController;

/**
 Specifies a mapping of phrase occurrence in this instance to its corresponding VDYEmbedState.
 */
@property (nullable, nonatomic, strong, readonly) NSDictionary *vdy_phraseOccurrenceToState;

/**
 Specifies the attributed text this instance displays.
 */
@property (nullable, nonatomic, copy) NSAttributedString *attributedText;

/**
 Specifies the pending change intended for this instance
 */
@property (nullable, nonatomic, strong) void(^vdy_pendingChangeBlock)(void);

@end
