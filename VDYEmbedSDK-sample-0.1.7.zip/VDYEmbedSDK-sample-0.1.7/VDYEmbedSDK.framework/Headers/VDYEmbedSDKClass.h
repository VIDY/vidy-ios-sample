//
//  VDYEmbedSDKClass.h
//  VDYEmbedSDK
//
//  Created by Arria Owlia on 6/13/18.
//  Copyright © 2018 Vidy. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const kVDYEmbedSDKConfigurationAppID;
extern NSString *const kVDYEmbedSDKConfigurationSAMPLEONLYPhrasesArray;

@protocol VDYDisplayDelegate;

@interface VDYEmbedSDK : NSObject

/**
 The instance's current configuration.
 */
@property (nullable, nonatomic, strong, readonly) NSDictionary *configuration;

/**
 The current configuration's AppID.
 */
@property (nullable, nonatomic, strong, readonly) NSString *appID;

/**
 Obtains the shared, singleton instance that manages the activation and deactivation of text displays.
 
 @return Shared, singleton instance
 */
+ (instancetype _Nonnull)sharedInstance NS_SWIFT_NAME(shared());

/**
 Sets the configuration, only when the current configuration is nil.
 
 @param configuration The configuration to use. For example: "@{ kVDYEmbedSDKConfigurationAppID : @"yourAppID" }
 */
- (void)setConfiguration:(NSDictionary *_Nonnull)configuration NS_SWIFT_NAME(configure(_:));

/**
 Activates Vidy-fication on a label.
 
 @param label The label to activate
 @param viewController The view controller instance that hosts the given label
 @param displayDelegate The delegate to receive display change callbacks
 */
- (void)activateLabel:(UILabel *_Nonnull)label viewController:(UIViewController *_Nonnull)viewController displayDelegate:(id<VDYDisplayDelegate> _Nullable)displayDelegate NS_SWIFT_NAME(activate(label:viewController:displayDelegate:));

/**
 Activates Vidy-fication on many labels.
 
 @param labels The labels to activate
 @param viewController The view controller instance that hosts the given labels
 @param displayDelegate The delegate to receive display change callbacks
 */
- (void)activateLabels:(NSArray *_Nonnull)labels viewController:(UIViewController *_Nonnull)viewController displayDelegate:(id<VDYDisplayDelegate> _Nullable)displayDelegate NS_SWIFT_NAME(activate(labels:viewController:displayDelegate:));

/**
 Activates Vidy-fication on many labels, using their associated postID
 
 @param labels The labels to activate that make up all labels for the given postID
 @param viewController The view controller instance that hosts the given labels
 @param postID The associated postID
 @param displayDelegate The delegate to receive display change callbacks
 */
- (void)activateLabels:(NSArray *_Nonnull)labels viewController:(UIViewController *_Nonnull)viewController postID:(NSString *_Nullable)postID displayDelegate:(id<VDYDisplayDelegate> _Nullable)displayDelegate NS_SWIFT_NAME(activate(labels:viewController:postID:displayDelegate:));

/**
 Deactivates a label with respect to Vidy-fication.
 
 @param label The label to deactivate
 */
- (void)deactivateLabel:(UILabel *_Nonnull)label NS_SWIFT_NAME(deactivate(label:));

/**
 Deactivates many labels with respect to Vidy-fication.
 
 @param labels The labels to deactivate
 */
- (void)deactivateLabels:(NSArray *_Nonnull)labels NS_SWIFT_NAME(deactivate(labels:));

@end
