//
//  NSString+VDYPhraseOccurrence.h
//  tapdelay
//
//  Created by Arria Owlia on 5/29/18.
//  Copyright © 2018 Vidy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (VDYPhraseOccurrence)

/**
 The phrase of this string, if it is in the phrase occurrence format ('phrase/occurrence').
 */
@property (nullable, nonatomic, strong, readonly) NSString *vdy_phrase;

/**
 The occurrence of the phrase of this string, if it is in the phrase occurrence format ('phrase/occurrence').
 */
@property (nullable, nonatomic, strong, readonly) NSNumber *vdy_occurrence;


/**
 Initializes properties
 */
+ (void)vdy_initializePhraseOccurrence;

/**
 Parses the phrase and occurrence of this string, if it is in the phrase occurrence format ('phrase/occurrence').

 @param phrase Phrase to be written to (out param)
 @param occurrence Occurrence to be written to (out param)
 @return Whether this string was successfully parsed as a phrase occurrence
 */
- (BOOL)vdy_parsePhrase:(NSString **_Nullable)phrase andOccurrence:(NSNumber **_Nullable)occurrence;


/**
 Returns the range of the input phrase occurrence string.

 @param phrase The phrase occurrence string to find
 @return The found range of the input phrase occurrence string within this string
 */
- (NSRange)vdy_rangeOfPhraseOccurrence:(NSString *_Nullable)phrase;

@end
