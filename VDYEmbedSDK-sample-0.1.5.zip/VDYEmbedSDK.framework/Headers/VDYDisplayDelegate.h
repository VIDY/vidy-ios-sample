//
//  VDYDisplayDelegate.h
//  VDYEmbedSDK
//
//  Created by Arria Owlia on 6/15/18.
//  Copyright © 2018 Vidy. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol VDYAttributedTextDisplay;

/**
 This delegate is meant to inform developers of changes performed or required
 during display.
 
 Future methods may deliver notifications that an overlay was presented/dismissed,
 and request status bar appearance changes.
 */
@protocol VDYDisplayDelegate <NSObject>

@optional

/**
 Delegate method called just before the container's `attributedText` property will change.
 
 @param container The container that hosts the changing `attributedText`
 */
- (void)vdy_containerTextWillChange:(UIView<VDYAttributedTextDisplay> *_Nonnull)container;

/**
 Delegate method called when the container's `vdy_pendingChangeBlock` property is updated. This
 change block will be called immediately by the SDK, most likely to update the container's
 `attributedText`. However, you may stop its execution by setting `update` to `NO`, and
 execute `changeBlock` at your convenience.

 @param container The container that hosts the updated `changedBlock`
 @param update Set this to `NO` to halt `changeBlock` from being executed. If set to `NO`,
 you must execute `changeBlock` on your own.
 @param changeBlock The block that will be executed immediately if `update` is not set.
 */
- (void)vdy_container:(UIView<VDYAttributedTextDisplay> *_Nonnull)container shouldUpdate:(BOOL *)update withPendingChange:(void(^)(void))changeBlock;

/**
 Delegate method called just after the container's `attributedText` property has changed.
 It is recommended to re-construct the parent view's layout.
 
 @param container The container that hosts the changing `attributedText`
 */
- (void)vdy_containerTextChanged:(UIView<VDYAttributedTextDisplay> *_Nonnull)container;

@end
