//
//  VDYDisplayDelegate.h
//  VDYEmbedSDK
//
//  Created by Arria Owlia on 6/15/18.
//  Copyright © 2018 Vidy. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol VDYAttributedTextDisplay;

/**
 This delegate is meant to inform developers of changes performed or required
 during display.
 
 Future methods may deliver notifications that an overlay was presented/dismissed,
 and request status bar appearance changes.
 */
@protocol VDYDisplayDelegate <NSObject>

@optional

/**
 Delegate method called just before the container's `attributedText` property will change.
 
 @param container The container that hosts the changing `attributedText`
 */
- (void)vdy_containerTextWillChange:(UIView<VDYAttributedTextDisplay> *_Nonnull)container;

/**
 Delegate method called just after the container's `attributedText` property has changed.
 It is recommended to re-construct the parent view's layout.
 
 @param container The container that hosts the changing `attributedText`
 */
- (void)vdy_containerTextChanged:(UIView<VDYAttributedTextDisplay> *_Nonnull)container;

@end
